import heapq
from collections import defaultdict

class SavingsAlgorithm:
    def __init__(self, graph, capacity):
        self.graph = graph  # Objeto do grafo
        self.capacity = capacity  # Capacidade do veículo
        self.routes = defaultdict(list)  # Dicionário que vai armazenar as rotas
        self.savings = []  # Lista para armazenar os savings (economias)
        self.visited = set()  # Conjunto para controlar os clientes visitados

    def calculate_savings(self):
        """Calcula a economia ao combinar dois clientes em uma rota única."""
        savings = []
        for u in self.graph.V:
            if u == self.graph.depot:
                continue
            for v in self.graph.V:
                if u != v and v != self.graph.depot:
                    # A economia é dada pela fórmula de redução de custo ao juntar dois clientes
                    # Savings = custo[depot -> u] + custo[depot -> v] - custo[u -> v]
                    cost_u = next((cost for node, cost in self.graph.graph[self.graph.depot] if node == u), float('inf'))
                    cost_v = next((cost for node, cost in self.graph.graph[self.graph.depot] if node == v), float('inf'))
                    cost_uv = next((cost for node, cost in self.graph.graph[u] if node == v), float('inf'))
                    saving = cost_u + cost_v - cost_uv
                    savings.append((saving, u, v))  # Salva a economia junto com os nós u e v
        self.savings = sorted(savings, reverse=True, key=lambda x: x[0])  # Ordena as economias em ordem decrescente

    def create_routes(self):
        """Cria as rotas baseadas nas economias calculadas."""
        # Inicializa as rotas com clientes individuais
        for u in self.graph.V:
            if u != self.graph.depot:
                self.routes[u].append(u)

        # Tenta combinar as rotas
        for saving, u, v in self.savings:
            # Verifica se já não foram visitados
            if u not in self.visited or v not in self.visited:
                # Verifica se podemos combinar as rotas (não ultrapassando a capacidade)
                if self.can_combine(u, v):
                    self.combine_routes(u, v)
                    self.visited.add(u)
                    self.visited.add(v)

    def can_combine(self, u, v):
        """Verifica se as rotas de u e v podem ser combinadas sem ultrapassar a capacidade do veículo."""
        route_u = self.routes[u]
        route_v = self.routes[v]

        # Verifica se a combinação das rotas não ultrapassa a capacidade
        demand_u = sum([demand for _, demand in self.graph.required_nodes if _ == u])
        demand_v = sum([demand for _, demand in self.graph.required_nodes if _ == v])
        
        if demand_u + demand_v <= self.capacity:
            return True
        return False

    def combine_routes(self, u, v):
        """Combina as rotas de u e v em uma única rota."""
        route_u = self.routes[u]
        route_v = self.routes[v]

        # Combina as rotas de u e v
        self.routes[u].extend(route_v)
        del self.routes[v]  # Remove a rota de v, pois ela foi combinada com u

    def get_routes(self):
        """Retorna as rotas finais."""
        return self.routes

    def print_routes(self):
        """Imprime as rotas geradas pelo algoritmo."""
        for route in self.routes.values():
            if route:
                print(f"Rota: {' -> '.join(map(str, route))}")


# Exemplo de uso
# Após instanciar o grafo e o SavingsAlgorithm, você pode rodar o algoritmo Savings.

# savings_algorithm = SavingsAlgorithm(graph, capacity)
# savings_algorithm.calculate_savings()
# savings_algorithm.create_routes()
# savings_algorithm.print_routes()

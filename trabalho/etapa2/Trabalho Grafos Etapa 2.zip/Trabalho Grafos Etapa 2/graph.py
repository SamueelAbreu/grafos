from collections import defaultdict
import math

class CustomGraphFinal:
    def __init__(self, parsed_data):
        self.V = set()  # Conjunto de vértices
        self.edges = []  # Lista de arestas
        self.arcs = []  # Lista de arcos
        self.required_nodes = set()  # Nós requeridos
        self.required_edges = []  # Arestas requeridas
        self.required_arcs = []  # Arcos requeridos
        self.depot = parsed_data["meta"]["depot"]
        self.capacity = parsed_data["meta"]["capacity"]
        self.graph = defaultdict(list)

        # Garantir que o depósito esteja sempre no grafo
        self.V.add(self.depot)

        # Adicionar nós requeridos ao grafo
        for node_id, demand, scost in parsed_data["ReN"]:
            self.required_nodes.add(node_id)
            self.V.add(node_id)

        # Adicionar arestas requeridas ao grafo
        for u, v, cost, demand, scost in parsed_data["ReE"]:
            self.edges.append((u, v, cost))
            self.required_edges.append((u, v, cost, demand, scost))
            self.graph[u].append((v, cost))
            self.graph[v].append((u, cost))
            self.V.add(u)
            self.V.add(v)

        # Adicionar arcos requeridos ao grafo
        for u, v, cost, demand, scost in parsed_data["ReA"]:
            self.arcs.append((u, v, cost))
            self.required_arcs.append((u, v, cost, demand, scost))
            self.graph[u].append((v, cost))
            self.V.add(u)
            self.V.add(v)

        # Adicionar arcos não requeridos
        for u, v, cost in parsed_data["NonRequiredArcs"]:
            self.arcs.append((u, v, cost))
            self.graph[u].append((v, cost))
            self.V.add(u)
            self.V.add(v)

    # Funções para obter métricas do grafo
    def num_vertices(self): 
        return len(self.V)

    def num_edges(self): 
        return len(self.edges)

    def num_arcs(self): 
        return len(self.arcs)

    def num_required_nodes(self): 
        return len(self.required_nodes)

    def num_required_edges(self): 
        return len(self.required_edges)

    def num_required_arcs(self): 
        return len(self.required_arcs)

    def density(self):
        """Calcula a densidade do grafo (número de arestas/arcos dividido por n*(n-1))."""
        n = len(self.V)
        m = len(self.edges) + len(self.arcs)
        return m / (n * (n - 1)) if n > 1 else 0

    def degrees(self):
        """Calcula o grau mínimo e máximo do grafo."""
        degree = defaultdict(int)
        for u in self.graph:
            for v, _ in self.graph[u]:
                degree[u] += 1
        return min(degree.values()), max(degree.values())

    def floyd_warshall(self):
        """Calcula a matriz de distâncias mínimas entre todos os pares de vértices."""
        nodes = sorted(list(self.V))
        node_to_index = {node: idx for idx, node in enumerate(nodes)}
        index_to_node = {idx: node for idx, node in enumerate(nodes)}

        n = len(nodes)
        INF = float('inf')
        dist = [[INF]*n for _ in range(n)]
        pred = [[-1]*n for _ in range(n)]

        # Inicializa distâncias e predecessores
        for idx in range(n):
            dist[idx][idx] = 0
            pred[idx][idx] = idx

        # Inicializa distâncias com as arestas do grafo
        for u in self.graph:
            for v, cost in self.graph[u]:
                i = node_to_index[u]
                j = node_to_index[v]
                dist[i][j] = min(dist[i][j], cost)
                pred[i][j] = i

        # Algoritmo de Floyd-Warshall
        for k in range(n):
            for i in range(n):
                for j in range(n):
                    if dist[i][k] + dist[k][j] < dist[i][j]:
                        dist[i][j] = dist[i][k] + dist[k][j]
                        pred[i][j] = pred[k][j]

        return dist, pred, node_to_index, index_to_node

    def average_path_length_and_diameter(self, dist):
        """Calcula o comprimento médio e o diâmetro do grafo."""
        n = len(dist)
        values = [dist[i][j] for i in range(n) for j in range(n) if i != j and dist[i][j] < float('inf')]
        return (sum(values) / len(values), max(values)) if values else (float('inf'), float('inf'))

    def connected_components(self):
        """Calcula os componentes conectados do grafo."""
        visited = set()
        components = []
        def dfs(v, comp):
            visited.add(v)
            comp.append(v)
            for u, _ in self.graph[v]:
                if u not in visited:
                    dfs(u, comp)
        for v in self.V:
            if v not in visited:
                comp = []
                dfs(v, comp)
                components.append(comp)
        return components

    def betweenness_centrality(self, dist, pred):
        """Calcula a centralidade de intermediação de cada nó."""
        n = len(dist)
        bt = {i: 0 for i in range(n)}
        for s in range(n):
            for t in range(n):
                if s != t and pred[s][t] != -1:
                    v = pred[s][t]
                    while v != s and v != -1:
                        bt[v] += 1
                        v = pred[s][v]
        return bt

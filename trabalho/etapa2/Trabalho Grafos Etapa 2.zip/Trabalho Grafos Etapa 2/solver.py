import os
import glob
import time
from parser import parse_instance_fully_correct
from savings import SavingsAlgorithm
from graph import CustomGraphFinal

# Função para salvar a solução no formato especificado
def save_solution(routes, instance_name, output_dir):
    out_path = os.path.join(output_dir, f'sol-{instance_name}.dat')
    with open(out_path, 'w') as fout:
        # Imprime o custo total da solução
        total_cost = sum(route.custo for route in routes)
        fout.write(f"{total_cost}\n")
        
        # Imprime o número de rotas
        fout.write(f"{len(routes)}\n")
        
        # Aqui, você pode colocar valores de clocks se necessário
        fout.write("0\n")  # Clocks referencia
        fout.write("0\n")  # Clocks solução
        
        # Imprime as rotas
        for idx, route in enumerate(routes, start=1):
            num_services = len(route.servicos_realizados)
            carga = int(route.carga)
            tam_rota = len(route.rota)
            
            # Cabeçalho da linha
            linha = f"0 1 {idx} {num_services} {route.custo} {carga} {tam_rota}"
            
            # Primeira visita ao depósito
            linha += f" (D {route.rota[0]},{route.rota[1]},{route.rota[1]})"
            
            # Serviços realizados
            for i in range(1, tam_rota - 1):
                u = route.rota[i-1]
                v = route.rota[i]
                id_serv = None
                for tipo in ['N', 'E', 'A']:
                    if (u, v, tipo) in route.servicos_realizados:
                        id_serv = tipo
                        break
                if id_serv:
                    linha += f" (S {id_serv},{u},{v})"
            
            # Última visita ao depósito
            linha += f" (D {route.rota[-2]},{route.rota[-1]},{route.rota[-1]})"
            
            fout.write(linha + "\n")

# Função principal para processar todas as instâncias
def process_instances(input_dir, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    
    # Percorre todas as instâncias no diretório de entrada
    

    
    for filepath in sorted(glob.glob(os.path.join(input_dir, '*.dat'))):
        filename = os.path.basename(filepath)
        # <<< Adicione este bloco:
        if filename.startswith('sol-'):
            continue
        # <<< Fim do bloco

        instance_name = os.path.splitext(filename)[0]
        print(f'Processando instância: {instance_name}')
        
        # Inicia a contagem do tempo de execução
        start_time = time.perf_counter()
        
        try:
            # Carrega e processa a instância
            parsed_data = parse_instance_fully_correct(filepath)
            g = CustomGraphFinal(parsed_data)
            
            # Executa o algoritmo Savings
            savings_algorithm = SavingsAlgorithm(g, g.capacity)
            savings_algorithm.calculate_savings()
            savings_algorithm.create_routes()
            routes = savings_algorithm.get_routes()

            # Salva a solução gerada
            save_solution(routes, instance_name, output_dir)
            
            # Tempo de execução
            end_time = time.perf_counter()
            print(f'Instância {instance_name} processada com sucesso em {end_time - start_time:.2f} segundos.')
        
        except Exception as e:
            print(f'Erro ao processar {instance_name}: {e}')

# Função principal para rodar o processo de todas as instâncias
if __name__ == "__main__":
    input_dir  = r'C:\Users\samue\OneDrive\Área de Trabalho\Trabalho Grafos Etapa 2\dados\MCGRP'
    output_dir = r'C:\Users\samue\OneDrive\Área de Trabalho\Trabalho Grafos Etapa 2\solucoes2'
    process_instances(input_dir, output_dir)

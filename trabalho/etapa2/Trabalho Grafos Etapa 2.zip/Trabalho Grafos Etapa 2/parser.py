import re

def parse_instance(file_path):
    data = {
        'meta': {},
        'ReN': [],         # Required nodes
        'ReE': [],         # Required edges
        'ReA': [],         # Required arcs
        'NonReqEdges': [], # Non-required edges
        'NonReqArcs': []   # Non-required arcs
    }

    section = None
    with open(file_path, 'r', encoding='utf-8') as f:
        for raw in f:
            line = raw.strip()
            if not line:
                continue
            # meta
            if line.startswith('Name:'):
                data['meta']['name'] = line.split(':',1)[1].strip()
                continue
            if line.startswith('Capacity:'):
                data['meta']['capacity'] = int(line.split(':',1)[1].strip())
                continue
            if line.startswith('Depot Node:'):
                data['meta']['depot'] = int(line.split(':',1)[1].strip())
                continue
            m = re.match(r'#(\w+):\s*(\d+)', line)
            if m:
                data['meta'][m.group(1)] = int(m.group(2))
                continue
            # section headers
            if line.startswith('ReN.'):
                section = 'ReN'
                continue
            if line.startswith('ReE.'):
                section = 'ReE'
                continue
            if line.startswith('ReA.'):
                section = 'ReA'
                continue
            if line.startswith('EDGE'):
                section = 'NonReqEdges'
                continue
            if line.startswith('ARC'):
                section = 'NonReqArcs'
                continue
            # parse entries
            parts = re.split(r'\s+', line)
            try:
                if section == 'ReN' and len(parts) >= 3 and parts[0].startswith('N'):
                    nid = int(parts[0][1:])
                    demand = int(parts[1])
                    scost = int(parts[2])
                    data['ReN'].append((nid, demand, scost))
                elif section == 'ReE' and len(parts) >= 6 and parts[0].startswith('E'):
                    _, u, v, cost, demand, scost = parts[:6]
                    data['ReE'].append((int(u), int(v), int(cost), int(demand), int(scost)))
                elif section == 'ReA' and len(parts) >= 6 and parts[0].startswith('A'):
                    _, u, v, cost, demand, scost = parts[:6]
                    data['ReA'].append((int(u), int(v), int(cost), int(demand), int(scost)))
                elif section == 'NonReqEdges' and len(parts) >= 4:
                    _, u, v, cost = parts[:4]
                    data['NonReqEdges'].append((int(u), int(v), int(cost)))
                elif section == 'NonReqArcs' and len(parts) >= 4:
                    _, u, v, cost = parts[:4]
                    data['NonReqArcs'].append((int(u), int(v), int(cost)))
            except ValueError:
                # malformed line, skip or log
                print(f"[WARN] malformed line in {section}: '{line}'")
                continue

    return data


if __name__ == '__main__':
    import sys, pprint
    if len(sys.argv) != 2:
        print(f"Usage: python {sys.argv[0]} <instance.dat>")
    else:
        inst = parse_instance(sys.argv[1])
        pprint.pprint(inst)


def parse_instance_fully_correct(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            lines = file.readlines()

        ReA = parse_arcos_obrigatorios(lines)     # ReA.
        ARC = parse_arcos_nao_obrigatorios(lines) # ARC
        ReE = parse_rees(lines)                   # ReE.
        EDGE = parse_edges(lines)                 # EDGE
        ReN = parse_ren(lines)                    # ReN.

        num_vertices = calcular_num_vertices(ReA, ARC, ReE, EDGE, ReN)

        capacidade = parse_capacidade(file_path)

        return {
            "ReA": ReA,
            "ARC": ARC,
            "ReE": ReE,
            "EDGE": EDGE,
            "ReN": ReN,
            "num_vertices": num_vertices,
            "capacidade": capacidade
        }

    except FileNotFoundError:
        print(f"Erro: O arquivo {file_path} não foi encontrado.")
    except Exception as e:
        print(f"Erro ao processar o arquivo {file_path}: {e}")
        return None

    return {
        "ReA": parsed_data["ReA"],
        "ARC": parsed_data["ARC"],
        "ReE": parsed_data["ReE"],
        "EDGE": parsed_data["EDGE"],
        "ReN": parsed_data["ReN"],
        "capacity": parsed_data["capacity"]
    }